"""
CS612 机械臂完整启动文件
启动顺序：
  1. Gazebo Sim（仿真环境）
  2. ros_gz_bridge（Gazebo <-> ROS2 话题桥接）
  3. cs612_joint_states_bridge：/joint_states_gz → /joint_states（与 URDF 关节名对齐）
  4. robot_state_publisher（订阅 /joint_states → 发布 TF，RViz RobotModel 与此同步）
  5. move_group（MoveIt 规划节点）
  6. RViz2（use_sim_time=true，与 /clock 一致）

仿真与 RViz「同一机械臂」同步依赖：Gazebo joint_state → 桥 → /joint_states → TF。
请勿在仿真同时另启 joint_state_publisher 往 /joint_states 发数，否则会冲突。

--- Ubuntu 24.04 + Conda RoboStack：为何装不了 ros-humble-ros-gz-bridge ---
  Humble 官方 deb 面向 Ubuntu 22.04；Noble(24.04) 应用 ROS 2 Jazzy。请用系统 Jazzy 的桥接
  （与 gz-sim10 匹配），MoveIt 等仍在 conda 的 ROS2 Humble 中运行；桥仅发布标准 sensor_msgs。

  需 sudo：可用仓库内脚本（默认中科大 USTC HTTP；清华 TUNA 若 HTTPS 握手失败可改 ROS_APT_MIRROR=official）：
    bash cs612_moveit_config/scripts/install_ros2_jazzy_bridge.sh
  安装后应有 /opt/ros/jazzy/setup.bash，本 launch 会优先用它启动 parameter_bridge。

  若节点 cs612_joint_states_bridge 报 PackageNotFoundError，或 RViz 中 link1..6 无 TF：
    colcon 未把 ament_python 包装入 install（install/.../site-packages 为空）。
    在 conda activate ros2 后于工作空间根目录执行：
      bash cs612_moveit_config/scripts/install_cs612_python_to_workspace.sh
    或：pip install --prefix <工作空间>/install/cs612_moveit_config <工作空间>/cs612_moveit_config
    再 source install/setup.bash（使 PYTHONPATH 含上述 site-packages）。

  ros_gz_bridge 桥接参数格式为 topic@ROS类型[GZ类型（[ 之后到参数结束均为 GZ 类型名，勿再额外加 ]）。
"""
import os
import shutil
from pathlib import Path

import yaml
from launch import LaunchDescription
from launch.actions import (
    ExecuteProcess,
    LogInfo,
    TimerAction,
)
from launch_ros.actions import Node

# 与 /usr/bin/gz（系统 Gazebo Sim，Noble 上常为 gz-sim10）匹配的 ros_gz_bridge 须与 libgz-msgs 主版本一致。
# Conda RoboStack 的 ros_gz_bridge 常落后于系统 gz，易出现 Unknown message type [8]/[9]。
# Ubuntu 24.04 无 ros-humble-* 官方 apt（Humble 面向 22.04）；应装 ros-jazzy-ros-gz-bridge（需先添加 ROS2 apt 源）。
# 本 launch 优先使用系统 /opt/ros/jazzy，其次 humble，否则回退 conda。
def _system_ros_setup_for_gz_bridge() -> tuple[Path | None, str]:
    jazzy = Path("/opt/ros/jazzy/setup.bash")
    humble = Path("/opt/ros/humble/setup.bash")
    if jazzy.is_file():
        return jazzy, "jazzy"
    if humble.is_file():
        return humble, "humble"
    return None, "conda"


def _clean_env_for_system_ros_bridge() -> tuple[dict, dict]:
    """
    仅为 system ROS bridge 进程提供最小环境，避免 conda 的 Python/LD_LIBRARY_PATH 污染
    导致 /opt/ros/* 下 rclpy 动态链接失败（undefined symbol）。
    """
    extra = {
        "PATH": "/usr/bin:/bin:/usr/local/bin",
        "HOME": os.environ.get("HOME", ""),
        "USER": os.environ.get("USER", ""),
        "LANG": os.environ.get("LANG", "C.UTF-8"),
        "DISPLAY": os.environ.get("DISPLAY", ":0"),
        "XAUTHORITY": os.environ.get("XAUTHORITY", ""),
        "WAYLAND_DISPLAY": os.environ.get("WAYLAND_DISPLAY", ""),
    }
    extra = {k: v for k, v in extra.items() if v}
    return {}, extra


def _get_project_paths(launch_file: Path) -> tuple[Path, Path]:
    launch_file = launch_file.resolve()
    try:
        from ament_index_python.packages import get_package_share_directory

        share = Path(get_package_share_directory("cs612_moveit_config"))
        if (share / "my_arms" / "urdf" / "CS612.urdf").is_file():
            return share, share
    except Exception:
        pass

    moveit_config_dir = launch_file.parent.parent
    project_root = moveit_config_dir.parent
    if (project_root / "my_arms" / "urdf" / "CS612.urdf").is_file():
        return project_root, moveit_config_dir

    raise FileNotFoundError(
        "找不到 my_arms/urdf/CS612.urdf。请先 colcon build 并 source install/setup.bash，"
        "或确认工程目录结构正确。"
    )


def _gz_executable() -> str:
    """优先使用系统 /usr/bin/gz，避免 PATH 里 conda 的 gz 与 conda OGRE 一起加载。"""
    if os.path.isfile("/usr/bin/gz") and os.access("/usr/bin/gz", os.X_OK):
        return "/usr/bin/gz"
    w = shutil.which("gz")
    if w and not ("miniconda" in w or "anaconda" in w or "conda/envs" in w.lower()):
        return w
    return w or "gz"


def _gz_clean_env_for_sim(gz_resource_path: str) -> tuple[dict, dict]:
    """
    对 ExecuteProcess 使用 env={} + additional_env，使 gz 完全不继承 conda 的 LD_LIBRARY_PATH。
    否则 Ogre 仍会加载 conda 的 RenderSystem_GL3Plus.so，与系统 gz-rendering-ogre2 混用会崩溃。
    """
    sys_ld = "/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu"
    # 保留运行 GUI / WSL 所需的最少变量
    extra = {
        "PATH": "/usr/bin:/bin:/usr/local/bin",
        "HOME": os.environ.get("HOME", ""),
        "USER": os.environ.get("USER", ""),
        "DISPLAY": os.environ.get("DISPLAY", ":0"),
        "XAUTHORITY": os.environ.get("XAUTHORITY", ""),
        "WAYLAND_DISPLAY": os.environ.get("WAYLAND_DISPLAY", ""),
        "LANG": os.environ.get("LANG", "C.UTF-8"),
        "GZ_SIM_RESOURCE_PATH": gz_resource_path,
        "LD_LIBRARY_PATH": sys_ld,
        "LIBGL_ALWAYS_SOFTWARE": os.environ.get("LIBGL_ALWAYS_SOFTWARE", "1"),
        "GALLIUM_DRIVER": os.environ.get("GALLIUM_DRIVER", "llvmpipe"),
    }
    # 去掉空值，避免覆盖为 ""
    extra = {k: v for k, v in extra.items() if v}
    return {}, extra


def _load_urdf_with_mesh_paths(project_root: Path) -> str:
    urdf_path = project_root / "my_arms" / "urdf" / "CS612.urdf"
    text = urdf_path.read_text(encoding="utf-8")
    mesh_uri = (project_root / "my_arms" / "meshes").resolve().as_uri()
    return text.replace("package://CS612urdf/meshes/", mesh_uri + "/")


def generate_launch_description():
    launch_file = Path(__file__)
    project_root, moveit_config_dir = _get_project_paths(launch_file)

    robot_description_content = _load_urdf_with_mesh_paths(project_root)

    srdf_path = moveit_config_dir / "config" / "CS612.srdf"
    robot_description_semantic_content = srdf_path.read_text(encoding="utf-8")

    with open(moveit_config_dir / "config" / "ompl_planning.yaml", "r", encoding="utf-8") as f:
        ompl_cfg = yaml.safe_load(f)

    with open(moveit_config_dir / "config" / "joint_limits.yaml", "r", encoding="utf-8") as f:
        joint_limits_doc = yaml.safe_load(f)

    with open(moveit_config_dir / "config" / "kinematics.yaml", "r", encoding="utf-8") as f:
        robot_description_kinematics = yaml.safe_load(f)

    world_file = project_root / "worlds" / "my_world.sdf"

    gz_parts = [
        project_root / "arms_models",
        project_root / "my_arms",
        project_root / "models",
        project_root / "models" / "gazebo_models",
        project_root / "worlds",
    ]
    gz_resource_path = ":".join(str(p) for p in gz_parts if p.is_dir())
    gz_empty_env, gz_add_env = _gz_clean_env_for_sim(gz_resource_path)
    gz_bin = _gz_executable()
    gazebo = ExecuteProcess(
        cmd=[gz_bin, "sim", "-r", str(world_file)],
        env=gz_empty_env,
        additional_env=gz_add_env,
        output="screen",
    )

    bridge_args = " ".join(
        [
            "'/world/arm_world/model/CS612_arm/joint_state@sensor_msgs/msg/JointState[gz.msgs.Model'",
            "'/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'",
            "'/cs612/suction/attach@std_msgs/msg/Empty[gz.msgs.Empty'",
            "'/cs612/suction/detach@std_msgs/msg/Empty[gz.msgs.Empty'",
            "--ros-args",
            "-p",
            "use_sim_time:=true",
            "-r",
            "/world/arm_world/model/CS612_arm/joint_state:=/joint_states_gz",
        ]
    )
    setup_path, bridge_distro = _system_ros_setup_for_gz_bridge()
    if setup_path is not None:
        # 避免 conda ros2/python 注入到系统 jazzy/humble 运行时，直接调用系统 bridge 可执行文件。
        bridge_bin = setup_path.parent / "lib" / "ros_gz_bridge" / "parameter_bridge"
        bridge_unset = (
            "unset PYTHONPATH LD_LIBRARY_PATH AMENT_PREFIX_PATH CMAKE_PREFIX_PATH "
            "COLCON_PREFIX_PATH ROS_DISTRO ROS_VERSION ROS_PYTHON_VERSION;"
        )
        bridge_empty_env, bridge_add_env = _clean_env_for_system_ros_bridge()
        gz_bridge = ExecuteProcess(
            cmd=[
                "bash",
                "-c",
                f"{bridge_unset} source {setup_path} && exec {bridge_bin} {bridge_args}",
            ],
            env=bridge_empty_env,
            additional_env=bridge_add_env,
            output="screen",
        )
        bridge_hint = LogInfo(
            msg=(
                f"[cs612_moveit_config] 使用系统 ROS {bridge_distro} 的 ros_gz_bridge（{setup_path}），"
                "与系统 /usr/bin/gz 消息版本一致。"
            ),
        )
    else:
        gz_bridge = Node(
            package="ros_gz_bridge",
            executable="parameter_bridge",
            name="gz_ros2_bridge",
            arguments=[
                "/world/arm_world/model/CS612_arm/joint_state"
                "@sensor_msgs/msg/JointState[gz.msgs.Model",
                "/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock",
                "/cs612/suction/attach@std_msgs/msg/Empty[gz.msgs.Empty",
                "/cs612/suction/detach@std_msgs/msg/Empty[gz.msgs.Empty",
            ],
            remappings=[
                (
                    "/world/arm_world/model/CS612_arm/joint_state",
                    "/joint_states_gz",
                ),
            ],
            parameters=[{"use_sim_time": True}],
            output="screen",
        )
        bridge_hint = LogInfo(
            msg=(
                "[cs612_moveit_config] 未找到 /opt/ros/jazzy 或 /opt/ros/humble：使用 conda 的 ros_gz_bridge。"
                "若出现 Unknown message type，请在 Ubuntu 24.04 添加 ROS2 APT 源并安装 "
                "ros-jazzy-ros-gz-bridge（见 bringup.launch.py 顶部说明）。"
            ),
        )

    # Gazebo 桥接多为 BEST_EFFORT；robot_state_publisher 默认 RELIABLE 订阅，若不匹配则收不到关节状态 → TF 断链。
    # 本节点 BEST_EFFORT 订阅 /joint_states_gz，规范化关节名后发布到 /joint_states。
    joint_states_bridge = Node(
        package="cs612_moveit_config",
        executable="cs612_joint_states_bridge",
        name="cs612_joint_states_bridge",
        output="screen",
        parameters=[{"use_sim_time": True}],
    )
    trajectory_action_bridge = Node(
        package="cs612_moveit_config",
        executable="cs612_trajectory_action_bridge",
        name="cs612_trajectory_action_bridge",
        output="screen",
        parameters=[{"use_sim_time": True}],
    )

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[
            {"robot_description": robot_description_content},
            {"use_sim_time": True},
            # 仿真时钟与 joint_states 时间戳不完全对齐时，避免 TF 断链导致 RViz TF 报警
            {"ignore_timestamp": True},
            {"publish_frequency": 50.0},
            # RViz「RobotModel」若从 /robot_description 话题取 URDF，须由 RSP 发布该话题
            {"publish_robot_description": True},
        ],
    )

    moveit_simple_controller_manager = {
        "controller_names": ["arm_controller"],
        "arm_controller": {
            "type": "FollowJointTrajectory",
            "action_ns": "follow_joint_trajectory",
            "default": True,
            "joints": ["Joint1", "Joint2", "Joint3", "Joint4", "Joint5", "Joint6"],
        },
    }

    move_group_node = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[
            {"robot_description": robot_description_content},
            {"robot_description_semantic": robot_description_semantic_content},
            {"robot_description_kinematics": robot_description_kinematics},
            {"robot_description_planning": joint_limits_doc},
            {"planning_pipelines": ["ompl"]},
            {"ompl": ompl_cfg},
            {"moveit_controller_manager": "moveit_simple_controller_manager/MoveItSimpleControllerManager"},
            {"moveit_simple_controller_manager": moveit_simple_controller_manager},
            {"allow_trajectory_execution": True},
            {"publish_robot_description_semantic": True},
            # 避免与 robot_state_publisher 同时在 /robot_description 上重复发布
            {"publish_robot_description": False},
            {"monitor_dynamics": False},
            {"use_sim_time": True},
        ],
    )

    rviz_config_file = moveit_config_dir / "config" / "cs612.rviz"
    rviz_args = (
        ["-d", str(rviz_config_file), "--ros-args", "-p", "use_sim_time:=true"]
        if rviz_config_file.is_file()
        else ["--ros-args", "-p", "use_sim_time:=true"]
    )
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=rviz_args,
        parameters=[
            {"robot_description": robot_description_content},
            {"robot_description_semantic": robot_description_semantic_content},
            {"robot_description_kinematics": robot_description_kinematics},
            {"use_sim_time": True},
        ],
    )

    # RViz 默认 Fixed Frame 常为 map；若 TF 中无 map，则 Global Status 报错且下拉看不到 base_link。
    # 发布 map -> base_link 单位变换，把机械臂接到世界根坐标系（MoveIt 教程常用做法）。
    map_to_base_tf = Node(
        package="tf2_ros",
        executable="static_transform_publisher",
        name="map_to_base_link",
        arguments=[
            "--frame-id", "map",
            "--child-frame-id", "base_link",
        ],
        parameters=[{"use_sim_time": True}],
        output="log",
    )

    # 等 Gazebo 世界与模型就绪后再起桥与 ROS 节点；过长拖慢首帧同步，过短可能桥接订阅失败。
    delayed_ros = TimerAction(
        period=1.5,
        actions=[
            gz_bridge,
            joint_states_bridge,
            trajectory_action_bridge,
            map_to_base_tf,
            robot_state_publisher,
            move_group_node,
            rviz_node,
        ],
    )

    return LaunchDescription(
        [
            bridge_hint,
            gazebo,
            delayed_ros,
        ]
    )
