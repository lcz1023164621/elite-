#!/usr/bin/env bash
# Ubuntu 24.04（Noble）+ Conda RoboStack：为与本项目 bringup.launch.py 一致，安装系统 ROS 2 Jazzy 的
# ros_gz_bridge（与 /usr/bin/gz、gz-sim10 消息兼容）。MoveIt 等仍在 conda 的 ROS2 Humble 中运行。
#
# 用法：在终端执行（需自行输入 sudo 密码，勿把密码写入脚本或发给他人）：
#   bash /path/to/cs612_moveit_config/scripts/install_ros2_jazzy_bridge.sh
#
# 参考：https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debians.html
#
# 中国大陆：默认使用中科大镜像（HTTP，可避免部分网络下 TUNA HTTPS 握手失败导致 apt 无法更新索引）。
#   环境变量 ROS_APT_MIRROR 可选：ustc（默认）| tuna | official
#   例：ROS_APT_MIRROR=official bash ...   （使用 packages.ros.org 官方源）
# 镜像说明：
#   - ustc  ：http://mirrors.ustc.edu.cn/help/ros2.html
#   - tuna  ：https://mirrors.tuna.tsinghua.edu.cn/help/ros2/
#   - official：海外网络或需与文档完全一致时使用

set -euo pipefail

if [[ "${EUID:-0}" -eq 0 ]]; then
  echo "请不要用 root 直接运行本脚本；请用普通用户执行，sudo 会在需要时提示。" >&2
  exit 1
fi

ROS_APT_MIRROR="${ROS_APT_MIRROR:-ustc}"
case "${ROS_APT_MIRROR}" in
  official)
    ROS2_REPO_BASE="http://packages.ros.org/ros2/ubuntu"
    ;;
  tuna)
    ROS2_REPO_BASE="https://mirrors.tuna.tsinghua.edu.cn/ros2/ubuntu"
    ;;
  ustc)
    ROS2_REPO_BASE="http://mirrors.ustc.edu.cn/ros2/ubuntu"
    ;;
  *)
    echo "无效的 ROS_APT_MIRROR=${ROS_APT_MIRROR}，请使用 official、tuna 或 ustc。" >&2
    exit 1
    ;;
esac

echo ">>> 使用 ROS 2 APT 镜像：${ROS_APT_MIRROR}（${ROS2_REPO_BASE}）"

echo ">>> 安装依赖：software-properties-common、curl、gnupg"
sudo apt-get update
sudo apt-get install -y software-properties-common curl gnupg

echo ">>> 启用 universe 源（若尚未启用）"
sudo add-apt-repository -y universe 2>/dev/null || true

echo ">>> 导入 ROS GPG key 并添加 ROS 2 APT 源（Ubuntu 代号：$(. /etc/os-release && echo "${UBUNTU_CODENAME}")）"
# 与 TUNA/官方文档一致：key 来自 rosdistro；国内镜像仅替换 deb 行的仓库 URL
# 若已存在旧 keyring，gpg 会交互询问 Overwrite 导致卡住；先删除并用 --batch 非交互写入。
sudo rm -f /usr/share/keyrings/ros-archive-keyring.gpg
curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.asc \
  | sudo gpg --batch --no-tty --dearmor -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] ${ROS2_REPO_BASE} $(. /etc/os-release && echo "${UBUNTU_CODENAME}") main" \
  | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

echo ">>> apt update"
sudo apt-get update

echo ">>> 安装 ros-jazzy-ros-gz-bridge"
sudo apt-get install -y ros-jazzy-ros-gz-bridge

if [[ -f /opt/ros/jazzy/setup.bash ]]; then
  echo ">>> 成功：已存在 /opt/ros/jazzy/setup.bash"
  echo ">>> 请重新 source 工作空间后运行：ros2 launch cs612_moveit_config move_group.launch.py"
else
  echo ">>> 未找到 /opt/ros/jazzy/setup.bash，请检查上方 apt 是否报错。" >&2
  exit 1
fi
