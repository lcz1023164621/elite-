"""将 Gazebo 经 ros_gz_bridge 发布的 joint_states 规范为 URDF 关节名并发布到 /joint_states。"""
from __future__ import annotations

import rclpy
from rclpy.node import Node
from rclpy.qos import (
    DurabilityPolicy,
    HistoryPolicy,
    QoSProfile,
    ReliabilityPolicy,
    qos_profile_sensor_data,
)
from sensor_msgs.msg import JointState

# RELIABLE + 较深队列：MoveIt/RViz 交互式标记与 CurrentStateMonitor 常按默认 Reliable 订阅 /joint_states；
# robot_state_publisher 使用 SensorData(BEST_EFFORT) 仍可接收 Reliable 发布。
_JOINT_STATES_PUBLISHER_QOS = QoSProfile(
    history=HistoryPolicy.KEEP_LAST,
    depth=50,
    reliability=ReliabilityPolicy.RELIABLE,
    durability=DurabilityPolicy.VOLATILE,
)

# 与 URDF 中可动关节名一致（顺序固定，便于 robot_state_publisher）
_ARM = ("Joint1", "Joint2", "Joint3", "Joint4", "Joint5", "Joint6")


def _strip_scope(name: str) -> str:
    if "::" in name:
        return name.split("::")[-1]
    return name


def _canonical_joint_name(raw: str) -> str | None:
    """将 Gazebo / 桥接可能输出的 joint1、Joint_2、model::Joint3 等映射到 URDF 中的 JointN。"""
    key = _strip_scope(raw)
    if key in _ARM:
        return key
    compact = key.replace("_", "").lower()
    if compact.startswith("joint") and len(compact) > 5:
        suf = compact[5:]
        if suf.isdigit():
            cand = f"Joint{int(suf)}"
            if cand in _ARM:
                return cand
    return None


class JointStatesBridge(Node):
    def __init__(self) -> None:
        super().__init__("cs612_joint_states_bridge")
        # robot_state_publisher 对 joint_states 要求 name 与 position 等长；发布端与 RSP 默认 SensorDataQoS 对齐。
        self._pub = self.create_publisher(JointState, "joint_states", _JOINT_STATES_PUBLISHER_QOS)
        self.create_subscription(JointState, "joint_states_gz", self._cb, qos_profile_sensor_data)
        self._logged_first = False

        self._last: JointState | None = None
        # 在首帧 GZ 数据到达前仍发布全零关节状态，避免 RViz 中除 base_link 外整链 TF 缺失
        self.create_timer(1.0 / 50.0, self._tick)
        # 不等定时器首帧，避免首周期内 robot_state_publisher 未收到任何 joint_states
        self._pub.publish(self._make_zero())

    def _make_zero(self) -> JointState:
        out = JointState()
        out.header.stamp = self.get_clock().now().to_msg()
        for j in _ARM:
            out.name.append(j)
            out.position.append(0.0)
            out.velocity.append(0.0)
            out.effort.append(0.0)
        return out

    def _build_from_gz(self, msg: JointState) -> JointState:
        pos: dict[str, float] = {}
        vel: dict[str, float] = {}
        eff: dict[str, float] = {}
        for i, raw in enumerate(msg.name):
            key = _canonical_joint_name(raw)
            if key is None:
                continue
            if i < len(msg.position):
                pos[key] = float(msg.position[i])
            if i < len(msg.velocity):
                vel[key] = float(msg.velocity[i])
            if i < len(msg.effort):
                eff[key] = float(msg.effort[i])

        # Model->JointState 有时 name 为空但 position 长度与关节数一致，按顺序对应 Joint1..6
        if not pos and len(msg.position) >= len(_ARM):
            for i, jn in enumerate(_ARM):
                pos[jn] = float(msg.position[i])
            if len(msg.velocity) >= len(_ARM):
                for i, jn in enumerate(_ARM):
                    vel[jn] = float(msg.velocity[i])
            if len(msg.effort) >= len(_ARM):
                for i, jn in enumerate(_ARM):
                    eff[jn] = float(msg.effort[i])

        out = JointState()
        out.header = msg.header
        if out.header.stamp.sec == 0 and out.header.stamp.nanosec == 0:
            out.header.stamp = self.get_clock().now().to_msg()
        for j in _ARM:
            out.name.append(j)
            out.position.append(pos.get(j, 0.0))
            out.velocity.append(vel.get(j, 0.0))
            out.effort.append(eff.get(j, 0.0))
        return out

    def _publish_stamped(self, template: JointState) -> None:
        stamped = JointState()
        stamped.header.stamp = self.get_clock().now().to_msg()
        stamped.name = list(template.name)
        stamped.position = list(template.position)
        stamped.velocity = list(template.velocity)
        stamped.effort = list(template.effort)
        self._pub.publish(stamped)

    def _cb(self, msg: JointState) -> None:
        # 仅更新状态，由 _tick 统一按固定频率发布，QoS 与 RSP 一致且首帧即有 TF
        if not self._logged_first and msg.name:
            self.get_logger().info(
                f"已收到 Gazebo 关节状态（示例关节名: {msg.name[0]}），/joint_states 将与仿真同步。"
            )
            self._logged_first = True
        self._last = self._build_from_gz(msg)

    def _tick(self) -> None:
        if self._last is None:
            self._pub.publish(self._make_zero())
        else:
            self._publish_stamped(self._last)


def main() -> None:
    rclpy.init()
    node = JointStatesBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.destroy_node()
        except Exception:
            pass
        try:
            rclpy.shutdown()
        except Exception:
            pass


if __name__ == "__main__":
    main()
