"""Bridge MoveIt FollowJointTrajectory action to Gazebo joint position command topics."""
from __future__ import annotations

import time
import subprocess
from typing import Dict, List

import rclpy
from control_msgs.action import FollowJointTrajectory
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import JointState

_ARM_JOINTS = ["Joint1", "Joint2", "Joint3", "Joint4", "Joint5", "Joint6"]


class TrajectoryActionBridge(Node):
    def __init__(self) -> None:
        super().__init__("cs612_trajectory_action_bridge")
        self._gz_bin = "/usr/bin/gz"
        self._gz_topics = {j: f"/model/CS612_arm/joint/{j}/0/cmd_pos" for j in _ARM_JOINTS}
        self._latest_positions: Dict[str, float] = {j: 0.0 for j in _ARM_JOINTS}
        self.create_subscription(
            JointState, "/joint_states", self._on_joint_states, qos_profile_sensor_data
        )

        self._action_server = ActionServer(
            self,
            FollowJointTrajectory,
            "/arm_controller/follow_joint_trajectory",
            goal_callback=self._goal_cb,
            cancel_callback=self._cancel_cb,
            execute_callback=self._execute_cb,
        )
        self.get_logger().info(
            "已启动 FollowJointTrajectory 桥接：/arm_controller/follow_joint_trajectory"
        )

    def _on_joint_states(self, msg: JointState) -> None:
        for idx, name in enumerate(msg.name):
            if name in self._latest_positions and idx < len(msg.position):
                self._latest_positions[name] = float(msg.position[idx])

    def _goal_cb(self, goal_request: FollowJointTrajectory.Goal) -> GoalResponse:
        jt = goal_request.trajectory
        if not jt.joint_names:
            self.get_logger().warn("拒绝空 joint_names 目标")
            return GoalResponse.REJECT
        if not jt.points:
            self.get_logger().warn("拒绝空轨迹目标")
            return GoalResponse.REJECT
        unknown = [j for j in jt.joint_names if j not in _ARM_JOINTS]
        if unknown:
            self.get_logger().warn(f"拒绝未知关节: {unknown}")
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT

    def _cancel_cb(self, _goal_handle) -> CancelResponse:
        self.get_logger().info("收到取消请求")
        return CancelResponse.ACCEPT

    def _publish_joint_positions(self, names: List[str], positions: List[float]) -> None:
        for idx, joint in enumerate(names):
            if joint in self._gz_topics and idx < len(positions):
                cmd = [
                    self._gz_bin,
                    "topic",
                    "-t",
                    self._gz_topics[joint],
                    "-m",
                    "gz.msgs.Double",
                    "-p",
                    f"data: {float(positions[idx])}",
                    "-n",
                    "1",
                ]
                subprocess.run(cmd, check=False, capture_output=True, text=True)

    def _duration_to_sec(self, duration_msg) -> float:
        return float(duration_msg.sec) + float(duration_msg.nanosec) * 1e-9

    def _execute_cb(self, goal_handle):
        goal = goal_handle.request
        traj = goal.trajectory
        joint_names = list(traj.joint_names)
        points = list(traj.points)
        start_wall = time.monotonic()

        feedback = FollowJointTrajectory.Feedback()
        feedback.joint_names = joint_names

        for point in points:
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                result = FollowJointTrajectory.Result()
                result.error_code = FollowJointTrajectory.Result.INVALID_GOAL
                result.error_string = "Goal canceled"
                return result

            target_t = self._duration_to_sec(point.time_from_start)
            now_t = time.monotonic() - start_wall
            sleep_t = target_t - now_t
            if sleep_t > 0.0:
                time.sleep(sleep_t)

            self._publish_joint_positions(joint_names, list(point.positions))

            feedback.desired = point
            feedback.actual.positions = [self._latest_positions.get(j, 0.0) for j in joint_names]
            feedback.error.positions = [
                d - a for d, a in zip(feedback.desired.positions, feedback.actual.positions)
            ]
            goal_handle.publish_feedback(feedback)

        goal_handle.succeed()
        result = FollowJointTrajectory.Result()
        result.error_code = FollowJointTrajectory.Result.SUCCESSFUL
        result.error_string = "Trajectory sent to Gazebo joint position topics"
        return result


def main() -> None:
    rclpy.init()
    node = TrajectoryActionBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.destroy_node()
        except Exception:
            pass
        try:
            rclpy.shutdown()
        except Exception:
            pass


if __name__ == "__main__":
    main()
